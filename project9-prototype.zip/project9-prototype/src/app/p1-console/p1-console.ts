import { Component, OnInit, inject } from '@angular/core';
import { Customer } from '../models/customer';
import { CustomerService } from '../services/customer';

@Component({
  selector: 'app-p1-console',
  imports: [],
  templateUrl: './p1-console.html',
  styleUrl: './p1-console.css',
})
export class P1Console implements OnInit {
  // 1. Inject the shared CustomerService
  private customerService = inject(CustomerService);

  // 2. Expose the read-only Signal so the template can also show the count
  customers = this.customerService.customers;

  // 3. Lifecycle Hook: ngOnInit runs automatically when Angular initializes this component
  // (Replacing the global top-to-bottom script execution from p1/script.js)
  ngOnInit(): void {
    this.printCustomerReport();
  }

  // 4. Component Method: Unpacks the strictly-typed Customer array and prints to console
  printCustomerReport(): void {
    const customerList: Customer[] = this.customers();

    console.log('=== CUSTOMER DATA REPORT (Angular P1 Component) ===\n\n');

    for (const customer of customerList) {
      const id = customer.customerId;
      const fullName = `${customer.firstName} ${customer.lastName}`;
      const email = customer.email;
      const phone = customer.phone;
      const address = `${customer.address}, ${customer.city}, ${customer.state} ${customer.zipCode}`;
      const status = customer.status;

      console.log(`Customer ID: ${id}`);
      console.log(`Name:        ${fullName}`);
      console.log(`Contact:     ${email} | ${phone}`);
      console.log(`Address:     ${address}`);
      console.log(`Status:      ${status}`);
      console.log('--------------------------------------------------');
    }

    console.log(`\nTotal Customers Processed: ${customerList.length}`);
  }
}
