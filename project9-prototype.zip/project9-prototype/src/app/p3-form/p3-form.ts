import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Customer } from '../models/customer';
import { CustomerService } from '../services/customer';

@Component({
  selector: 'app-p3-form',
  // Teaching Moment: FormsModule unlocks [(ngModel)] two-way data binding in standalone components!
  imports: [FormsModule],
  templateUrl: './p3-form.html',
  styleUrl: './p3-form.css',
})
export class P3Form {
  // 1. Inject the shared CustomerService
  private customerService = inject(CustomerService);

  // 2. Expose the read-only Signal of Customer[] for the template's @for loop
  customers = this.customerService.customers;

  // 3. Strictly-typed form state object (replaces 10 separate document.getElementById calls!)
  newCustomer: Customer = this.createEmptyCustomer();

  // 4. Add the new customer via CustomerService and reset the form
  addCustomer(): void {
    // Push a copy of the form state into the shared service Signal
    this.customerService.addCustomer({ ...this.newCustomer });

    // Reset all form inputs with a single assignment
    this.newCustomer = this.createEmptyCustomer();

    console.log(
      'Customer added via CustomerService! Total array length is now: ' +
        this.customers().length
    );
  }

  private createEmptyCustomer(): Customer {
    return {
      customerId: '',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      status: 'Active',
    };
  }
}
