import { ComponentFixture, TestBed } from '@angular/core/testing';

import { P2Dom } from './p2-dom';

describe('P2Dom', () => {
  let component: P2Dom;
  let fixture: ComponentFixture<P2Dom>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [P2Dom],
    }).compileComponents();

    fixture = TestBed.createComponent(P2Dom);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
