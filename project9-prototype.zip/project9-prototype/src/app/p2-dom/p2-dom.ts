import { Component, OnInit, inject } from '@angular/core';
import { Customer } from '../models/customer';
import { CustomerService } from '../services/customer';

@Component({
  selector: 'app-p2-dom',
  imports: [],
  templateUrl: './p2-dom.html',
  styleUrl: './p2-dom.css',
})
export class P2Dom implements OnInit {
  // 1. Inject the shared CustomerService (same service used by P1Console)
  private customerService = inject(CustomerService);

  // 2. Expose the read-only Signal of Customer[] directly to our HTML template
  customers = this.customerService.customers;

  // 3. Preserve the console report from App 2 when the component initializes
  ngOnInit(): void {
    const customerList: Customer[] = this.customers();
    console.log('=== CUSTOMER DATA REPORT (Angular P2 DOM Component) ===\n\n');

    for (const customer of customerList) {
      const id = customer.customerId;
      const fullName = `${customer.firstName} ${customer.lastName}`;
      const email = customer.email;
      const phone = customer.phone;
      const address = `${customer.address}, ${customer.city}, ${customer.state} ${customer.zipCode}`;
      const status = customer.status;

      console.log(`Customer ID: ${id}`);
      console.log(`Name:        ${fullName}`);
      console.log(`Contact:     ${email} | ${phone}`);
      console.log(`Address:     ${address}`);
      console.log(`Status:      ${status}`);
      console.log('--------------------------------------------------');
    }

    console.log(`\nTotal Customers Rendered to DOM: ${customerList.length}`);
  }
}
