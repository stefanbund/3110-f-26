import { Component, inject } from '@angular/core';
import { CustomerService } from '../services/customer';

@Component({
  selector: 'app-test-customer',
  imports: [],
  templateUrl: './test-customer.html',
  styleUrl: './test-customer.css',
})
export class TestCustomer {
  // Use the inject() function to grab our service
  private customerService = inject(CustomerService);

  // Expose the read-only signal to our HTML template
  customerList = this.customerService.customers;
}