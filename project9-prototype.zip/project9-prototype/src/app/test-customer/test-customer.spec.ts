import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestCustomer } from './test-customer';

describe('TestCustomer', () => {
  let component: TestCustomer;
  let fixture: ComponentFixture<TestCustomer>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TestCustomer],
    }).compileComponents();

    fixture = TestBed.createComponent(TestCustomer);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
