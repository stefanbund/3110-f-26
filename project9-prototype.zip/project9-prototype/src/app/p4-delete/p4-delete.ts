import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Customer } from '../models/customer';
import { CustomerService } from '../services/customer';

@Component({
  selector: 'app-p4-delete',
  imports: [FormsModule],
  templateUrl: './p4-delete.html',
  styleUrl: './p4-delete.css',
})
export class P4Delete {
  // 1. Inject the shared CustomerService
  private customerService = inject(CustomerService);

  // 2. Expose the read-only Signal of Customer[] for the template's @for loop
  customers = this.customerService.customers;

  // 3. Strictly-typed form state object
  newCustomer: Customer = this.createEmptyCustomer();

  // 4. Add a new customer via CustomerService
  addCustomer(): void {
    this.customerService.addCustomer({ ...this.newCustomer });
    this.newCustomer = this.createEmptyCustomer();
    console.log(
      'Customer added! Total array length is now: ' + this.customers().length
    );
  }

  // 5. Delete a customer by index via CustomerService (New in P4)
  deleteCustomer(indexToRemove: number): void {
    this.customerService.deleteCustomer(indexToRemove);
    console.log(
      'Customer deleted at index ' +
        indexToRemove +
        '! Total array length is now: ' +
        this.customers().length
    );
  }

  private createEmptyCustomer(): Customer {
    return {
      customerId: '',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      zipCode: '',
      status: 'Active',
    };
  }
}
