import { Injectable, signal } from '@angular/core';
import { Customer } from '../models/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  
  // Teaching Moment: We use Angular Signals to hold our full 5-customer dataset
  // migrated from p1/customers.json, strictly typed with the Customer interface.
  private customerData = signal<Customer[]>([
    {
      customerId: 'CUST-001',
      firstName: 'Alice',
      lastName: 'Smith',
      email: 'alice.smith@example.com',
      phone: '555-0101',
      address: '123 Maple St',
      city: 'Springfield',
      state: 'IL',
      zipCode: '62701',
      status: 'Active'
    },
    {
      customerId: 'CUST-002',
      firstName: 'Bob',
      lastName: 'Johnson',
      email: 'bob.j@example.com',
      phone: '555-0102',
      address: '456 Oak Ave',
      city: 'Metropolis',
      state: 'NY',
      zipCode: '10001',
      status: 'Inactive'
    },
    {
      customerId: 'CUST-003',
      firstName: 'Carol',
      lastName: 'Williams',
      email: 'carol.w@example.com',
      phone: '555-0103',
      address: '789 Pine Rd',
      city: 'Gotham',
      state: 'NJ',
      zipCode: '07001',
      status: 'Active'
    },
    {
      customerId: 'CUST-004',
      firstName: 'David',
      lastName: 'Brown',
      email: 'dbrown@example.com',
      phone: '555-0104',
      address: '321 Elm St',
      city: 'Star City',
      state: 'CA',
      zipCode: '90210',
      status: 'Active'
    },
    {
      customerId: 'CUST-005',
      firstName: 'Eve',
      lastName: 'Davis',
      email: 'eve.davis@example.com',
      phone: '555-0105',
      address: '654 Birch Blvd',
      city: 'Central City',
      state: 'OH',
      zipCode: '43215',
      status: 'Pending'
    }
  ]);

  // Expose the data as a read-only signal so components can display or read it
  // without accidentally mutating the underlying array directly.
  customers = this.customerData.asReadonly();

  // CREATE (Introduced in P3)
  addCustomer(newCustomer: Customer): void {
    this.customerData.update(currentList => [...currentList, newCustomer]);
  }

  // DELETE (Introduced in P4)
  // Replaces customers.splice(indexToRemove, 1) + renderCustomers() from p4/app4.js
  deleteCustomer(indexToRemove: number): void {
    this.customerData.update(currentList =>
      currentList.filter((_, index) => index !== indexToRemove)
    );
  }
}
