# Student Guide: Building an Angular Service (`customer.ts`)

An in-depth guide on how and why to create a centralized **Data Service** in modern Angular using **Signals** and **Dependency Injection**.

---

## 1. The Core Concept: Separation of Concerns

Before writing any code, it is essential to understand **why** we do not keep our data inside components.

| Role | What it handles | What it should NEVER handle |
| :--- | :--- | :--- |
| **Component** (`.ts`, `.html`, `.css`) | The Presentation Layer: buttons, forms, user events, rendering UI cards. | Storing database arrays, making raw API requests, calculating cross-app business rules. |
| **Service** (`.ts`) | The Data Layer: holding data arrays, talking to backend REST APIs, providing CRUD operations. | Manipulating HTML, handling CSS styling, direct DOM interaction. |

> **Analogy**: Think of a restaurant. 
> - The **Component** is the waiter. The waiter talks to the customer (user), takes orders, and places plates on the table.
> - The **Service** is the kitchen / pantry. It stores ingredients (data) and prepares food (business logic). The waiter doesn't cook the food at the table!

---

## 2. Architecture Diagram

```
+--------------------------------------------------------------+
|             CustomerService (Single Source of Truth)        |
|                                                              |
|   [private customerData] (Writable Signal)                  |
|             │                                                |
|             ▼                                                |
|   [customers] (Read-Only Signal)                            |
|             │                                                |
|   [addCustomer()] (State Mutation Method)                   |
+--------------------------------------------------------------+
                               │
                inject(CustomerService)
                               │
                               ▼
+--------------------------------------------------------------+
|            TestCustomer Component (Presentation)             |
|                                                              |
|   customerList = this.customerService.customers              |
+--------------------------------------------------------------+
                               │
                      data-binding: ()
                               ▼
+--------------------------------------------------------------+
|                test-customer.html (Template)                 |
|                                                              |
|   @for (customer of customerList(); track customer.customerId)|
+--------------------------------------------------------------+
```

---

## 3. Step 1: Scaffold with the Angular CLI

Never create service files manually. Always use the Angular CLI so that it handles directory conventions and generates a test suite file automatically:

```bash
ng generate service services/customer
```
*(Shorthand: `ng g s services/customer`)*

This creates two files in `src/app/services/`:
1. `customer.ts`: The actual service logic.
2. `customer.spec.ts`: The unit test file.

---

## 4. Step 2: Line-by-Line Anatomy of `customer.ts`

Here is the complete implementation of `src/app/services/customer.ts`:

```typescript
import { Injectable, signal } from '@angular/core';
import { Customer } from '../models/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  
  // 1. Private data store wrapped in a reactive Signal
  private customerData = signal<Customer[]>([
    {
      customerId: "CUST-001",
      firstName: "Alice",
      lastName: "Smith",
      email: "alice.smith@example.com",
      phone: "555-0101",
      address: "123 Maple St",
      city: "Springfield",
      state: "IL",
      zipCode: "62701",
      status: "Active"
    },
    {
      customerId: "CUST-002",
      firstName: "Bob",
      lastName: "Johnson",
      email: "bob.j@example.com",
      phone: "555-0102",
      address: "456 Oak Ave",
      city: "Metropolis",
      state: "NY",
      zipCode: "10001",
      status: "Inactive"
    }
  ]);

  // 2. Expose read-only access to components
  customers = this.customerData.asReadonly();

  // 3. Controlled mutation method
  addCustomer(newCustomer: Customer): void {
    this.customerData.update(currentList => [...currentList, newCustomer]);
  }
}
```

### Deep Dive into the Code:

### A. `@Injectable({ providedIn: 'root' })`
* **What it does**: Tells Angular's **Dependency Injection (DI)** container that this class can be injected into any component.
* **Why `providedIn: 'root'`**: This registers the service as a **Singleton**. A singleton means there is only **one shared instance** across your entire app. If Component A adds a customer, Component B instantly sees the update!

### B. `signal<Customer[]>([...])`
* In modern Angular (v16+), **Signals** replace older, complex RxJS reactive patterns.
* A Signal is a value wrapper that notifies Angular when its content changes so Angular can surgically update only the HTML nodes that depend on it.
* `<Customer[]>` ensures strict TypeScript typing using the `Customer` interface.

### C. `private customerData` vs `customers = this.customerData.asReadonly()`
* **Encapsulation**: We mark `customerData` as `private` so that components cannot do dangerous operations like `customerData.set([])` directly.
* `.asReadonly()` allows components to listen and read the data, but forces them to use service methods (like `addCustomer()`) to make modifications.

### D. Updating Signal State: `.update(...)`
* Signals are updated immutably:
  ```typescript
  this.customerData.update(currentList => [...currentList, newCustomer]);
  ```
* Rather than mutating the array (`push`), we return a brand-new array using the spread operator (`...`). This guarantees change detection fires cleanly.

---

## 5. Step 3: Connecting the Service to a Component

To use the service inside a component (e.g., `TestCustomer`), follow these 3 steps:

### 1. In the Component TypeScript (`test-customer.ts`):
Use Angular's modern `inject()` function:

```typescript
import { Component, inject } from '@angular/core';
import { CustomerService } from '../services/customer';

@Component({
  selector: 'app-test-customer',
  imports: [],
  templateUrl: './test-customer.html',
  styleUrl: './test-customer.css',
})
export class TestCustomer {
  // 1. Inject the singleton instance of CustomerService
  private customerService = inject(CustomerService);

  // 2. Grab the readonly signal from the service
  customerList = this.customerService.customers;
}
```

### 2. In the Component HTML (`test-customer.html`):
Use the `@for` control flow block:

```html
<div class="header">
  <h2>Customer Directory</h2>
  <p>Data provided by CustomerService</p>
</div>

<!-- CRITICAL: Remember to invoke the signal with () -->
@for (customer of customerList(); track customer.customerId) {
  <div class="test-card">
    <h3>{{ customer.firstName }} {{ customer.lastName }}</h3>
    <p><strong>ID:</strong> {{ customer.customerId }}</p>
    <p><strong>Status:</strong> {{ customer.status }}</p>
    <p><strong>Contact:</strong> {{ customer.email }}</p>
  </div>
} @empty {
  <div class="test-card">
    <p>No customers found.</p>
  </div>
}
```

---

## 6. Common Student Mistakes & Troubleshooting

| Symptom / Error | Cause | Solution |
| :--- | :--- | :--- |
| `TS2339: Property 'customerList' does not exist on type 'TestCustomer'` | Component template has `@for (customer of customerList())`, but the `.ts` file didn't define `customerList`. | Define `customerList = this.customerService.customers;` in the component class. |
| Nothing renders, or `[object Object]` displays | Forgot the parentheses `()` when reading a Signal in HTML. | Signals are getter functions! Write `customerList()`, not `customerList`. |
| `NullInjectorError: No provider for CustomerService!` | Removed or missed `@Injectable({ providedIn: 'root' })` above the service class. | Ensure `@Injectable({ providedIn: 'root' })` is right above the service class export. |
| Data changes don't show up on screen | Mutated the array directly (e.g., `.push()`) instead of updating the signal. | Use `signal.update(list => [...list, newItem])` to emit a new reference. |

---

## 7. Quick Review Quiz for Students

1. **Why do we mark `customerData` as `private`?**
   * *Answer*: To prevent external components from directly altering or clearing data without going through authorized service methods.
2. **What does `providedIn: 'root'` do?**
   * *Answer*: It registers the service globally as a singleton, ensuring every component shares the exact same live data.
3. **Why do we write `customerList()` with parentheses in HTML?**
   * *Answer*: Because a Signal in Angular is a getter function; invoking it with `()` reads its latest value.
